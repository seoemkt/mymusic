Providers & Services
====================

.. automodule:: xl.providers

.. data:: MANAGER

   Singleton instance of the :class:`ProviderManager`

.. autofunction:: register

.. autofunction:: unregister

.. autofunction:: get

.. autofunction:: get_provider

.. autoclass:: ProviderManager 

.. autoclass:: ProviderHandler

