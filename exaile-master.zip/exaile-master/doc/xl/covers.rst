Cover
=====

.. automodule:: xl.covers

Cover Manager
*************

.. autodata:: MANAGER

.. autoclass:: CoverManager
    :members:

Cover Search Methods
********************

.. autoclass:: CoverSearchMethod
    :members:

.. autoclass:: TagCoverFetcher

.. autoclass:: LocalFileCoverFetcher
