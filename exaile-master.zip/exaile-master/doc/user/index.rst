User's guide
============

The great thing about Exaile is that it's really simple to use, so we
haven't written instructions on how to use it! ;)

.. toctree::

    deps
    install
    win32
    osx
    faq
   
